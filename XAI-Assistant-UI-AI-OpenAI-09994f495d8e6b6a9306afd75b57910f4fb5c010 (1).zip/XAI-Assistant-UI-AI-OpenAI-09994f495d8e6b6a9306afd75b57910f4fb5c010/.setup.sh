#!/usr/bin/env bash
set -e

# Install Node packages
npm install
